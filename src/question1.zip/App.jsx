import React from 'react'

function App() {
  return (
    <div>
      <h1>Question 1 completed</h1>
    </div>
  )
}

export default App
